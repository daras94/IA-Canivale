This repo contains files from Danny Yoo's while-loop repository, 
adapted for Racket's 'pkg' interface. Install it using

```
raco pkg install while-loop
```

note that it lists dependencies, meaning that it if you use
PRE-6.0 DrRacket and the "Install Package..." menu entry,
you may have problems.

